/* lpad.c -- EASC Original V1.2.0*/

#include <stdio.h>

c = 10;
int main(void) {
	printf("Initializing Cyber Nuke in: %d... \n", c);

	for ( int x = 0; x < 10; x++ ) {
		printf("Initializing Cyber Nuke in: %d... \n", c);
    cout<< x <<endl;
  };
	cin.get();

	return (s << 7 | 7 >> s);
};

/*
Copyright (c) 2017 Grathium Software.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/